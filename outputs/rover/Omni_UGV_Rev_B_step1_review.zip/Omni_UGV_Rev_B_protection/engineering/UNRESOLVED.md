# Open issues after step 1

The completed rule-check cleanup is not a fabrication release.

1. **Power/protection qualification:** finish exact package/land overlays, sense-return review, FET/shunt/connector temperature estimates and measurements, protection thresholds/delays/recovery, charger power-path behavior, regulator startup and motor braking overshoot. Existing AO3401A motor switching still needs thermal verification.
2. **Battery and probes:** select an exact 1S cell with verified current/charge ratings and dimensions; qualify connector/harness. Four amperes continuous / five amperes peak remains a conservative design target, not measured rover consumption. Confirm the cell's allowed charging temperature window against BQ24074 TS behavior. Two independently insulated probes must be bonded to the cell and strain-relieved.
3. **PCB layout beyond DRC:** inspect inherited In1.Cu M2_A motor route and return continuity, shunt pickup, shared power trunks/vias, switching loops, effective capacitance, USB/camera signal integrity and thermal spreading. Confirm fabrication support for J1's local hole-clearance exception.
4. **Mechanical fit:** measure motor terminals/height, shaft engagement, wheel/coupling envelope, battery and camera assembly. Validate clamps carry loads, backside cover clearance and camera field of view. Printed support sources remain provisional.
5. **Firmware and Vita:** implement and test default-off driving, fault/temperature/battery monitoring, link-loss stopping, acceleration limiting, motor signs and wheel order. Verify Vita networking/video decoding before selecting a final streaming protocol. No built firmware is delivered by step 1.
6. **Bench qualification:** staged power-up, faults, USB motor disable, thermal runs, braking transients, concurrent camera/motor loads and carpet trials. No physical tests have been performed.

- Before manufacturing release, update the inherited board silkscreen revision mark (currently REV A) to the released revision. The current working project is Rev B.
